#ifndef OBJECT_H
#define OBJECT_H
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <string>
#include <globals.h>
#include <gTexture.h>
#include <vector>

class Object
{
    public:
        Object();
        Object(int type, float x, float y, Uint8 width, Uint8 height, int depth);
        Object(int type, std::string path, float x, float y, int depth);
        Object(int type, std::string path, Uint8 r, Uint8 g, Uint8 b, float x, float y, int depth);
        virtual ~Object();

        int getType();

        void setAttribute(int num, int value);
        void addAttribute(int num, int value);
        int attribute1;
        int attribute2;
        int attribute3;
        int attribute4;
        int attribute5;
        int attribute9;
        int attribute9array[8] = {0,0,0,0,0,0,0,0};
        int getAttribute(int num);

        void setCollideTypes(std::vector<int> types);
        void addCollideType(int type);
        bool removeCollideType(int type);
        std::vector<int>* getCollideTypes();

        void setX(float x);
        float getX();

        void setY(float y);
        float getY();

        void setSpeed(float speed);
        float getSpeed();

        void setDirection(float dir);
        float getDirection();

        void setWidth(Uint8 width);
        Uint8 getWidth();
        void setHeight(Uint8 height);
        Uint8 getHeight();

        void setSpriteIndex(Uint8 i);
        Uint8 getSpriteIndex();

        void setDepth(int depth);
        int getDepth();

        void setDrawDepth(int depth);
        int getDrawDepth();

        bool intersects(Object* other);

        bool contains(float px, float py);

        void o_move();
        bool oc_move();

        void o_step();

        void setAlarm(int alarm, int time);
        int getAlarm(int alarm);
        void alarm_step();

        bool place_meeting(float x, float y, gTexture* tex, std::vector<int> collideTypes);
        bool place_meeting(int x, int y, Object* obj);
        bool place_meeting(Object* obj);
        bool place_meeting(Object* obj, int width, int height);
        bool place_meeting(Object* obj, float x, float y, float width, float height);

        bool compByDepth(Object* i, Object* j);
        bool compByDrawDepth(Object* i, Object* j);

        void setAngle(double ang);
        double getAngle();

        gTexture* getTexture();

        void draw();

    protected:

    private:
        void init();
        int type;
        gTexture* tex;
        Uint8 sprInd;
        Uint8 width;
        Uint8 height;
        float x;
        float y;
        float speed;
        float dir;
        int depth;
        int drawDepth;
        double angle;
        bool loadTexture(std::string path);
        bool loadTextureColorKey(std::string path, Uint8 r, Uint8 g, Uint8 b);
        std::vector<int> collideTypes;
        int alarm[10];
};

#endif // OBJECT_H
