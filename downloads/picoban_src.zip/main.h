#ifndef MAIN_H
#define MAIN_H

#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>
#include <SDL_mixer.h>
#include <stdio.h>
#include <string>
#include <sstream>
#include <globals.h>
#include <Object.h>
#include <vector>
#include <fstream>
#include <cstdlib>
#include <iterator>
#include <iostream>


#endif

