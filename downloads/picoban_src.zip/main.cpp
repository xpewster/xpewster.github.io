//Using SDL and standard IO
#include <main.h>

const int SCREEN_WIDTH = 1920;
const int SCREEN_HEIGHT = 1080;
const int DEFAULT_WIDTH = 640;
const int DEFAULT_HEIGHT = 480;

/*bool initSDL(SDL_Window*& window, SDL_Surface*& surfScreen);
SDL_Surface* loadImage(std::string type, const char* directory);
bool loadAssets();
void exit();
const char* toString(int i);*/

SDL_Window* window = NULL;
SDL_Surface* surfScreen = NULL;
SDL_Renderer* renderer = NULL;
TTF_Font* fontBody = NULL;
SDL_Rect view;
SDL_Color red{255,0,0};
std::map<int,std::vector<Object*>> objects;
int levelX = 0;
int levelY = 0;

enum o_type {OT_BUTTON,OT_BLOCK,OT_GOAL,OT_ARROW,OT_KEY,OT_GATE,OT_PLAYER,OT_SPECIAL,OT_LADDER};
enum screen_type {SC_MENU,SC_LEVEL};
enum center_type{CT_TOPLEFT,CT_TOPRIGHT,CT_TOPMIDDLE};
enum attribute{
    AT_TYPE = 1,
    AT_ID = 2,
    AT_COLLISION = 3,
    AT_VISIBLE = 4,
    AT_PUSHED = 5,
    AT_TYPE_ARROW = 0,
    AT_TYPE_KEY = 1,
    AT_TYPE_GATE = 2,
    AT_TYPE_BUTTON = 3,//
    AT_TYPE_LADDER = 4,
    AT_ID_0 = 0,
    AT_ID_1 = 1,
    AT_ID_2 = 2,//
    AT_SOLID = 0,
    AT_PASSTHROUGH = 1,
    AT_V_VISIBLE = 0,
    AT_V_HIDDEN = 1,
    AT_BORDER = 9
};

bool initSDL(SDL_Window*& window, SDL_Surface*& surfScreen){
    if ( SDL_Init(SDL_INIT_VIDEO) < 0){
        printf("sdl_init error\n");
        return 0;
    } else {
        window = SDL_CreateWindow("Picoban", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, DEFAULT_WIDTH, DEFAULT_HEIGHT, SDL_WINDOW_SHOWN);
        if (window == NULL){
            printf("window creation error\n");
            return 0;
        } else {
            surfScreen = SDL_GetWindowSurface( window );
            if (surfScreen == NULL){
                printf("surface retrieval error\n");
            }
        }
        renderer = SDL_CreateRenderer(window,-1,SDL_RENDERER_ACCELERATED);
        if (renderer == NULL){
            printf("renderer creation error\n");
            return 0;
        } else {
            SDL_SetRenderDrawColor(renderer, 0xFF, 0xFF, 0xFF, 0xFF);
            int flag = IMG_INIT_PNG;
            if (!(IMG_Init(flag) & flag)){
                printf("png initialization error\n");
                return 0;
            }
        }
    }
    if (TTF_Init() == -1){
        printf("ttf initialization error\n");
        return 0;
    }
    if (SDL_Init(SDL_INIT_AUDIO) < 0){
        printf("audio initialization error\n");
        return 0;
    }
    if (Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,2,2048) < 0){
        printf("SDL_mixer could not open: %s\n",Mix_GetError());
        return 0;
    }
    return 1;
}
void setView(SDL_Rect* view, int x, int y, int w, int h){
    view->x = x;
    view->y = y;
    view->w = w;
    view->h = h;
}
SDL_Surface* loadImage(std::string type, const char* directory){
    SDL_Surface* surfConverted;
    if (type == "bmp"){
        SDL_Surface* surfLoad = SDL_LoadBMP(directory);
        if (surfLoad == NULL){
            printf("error loading image at:");
            printf(directory);
        }
        surfConverted = SDL_ConvertSurface(surfLoad,surfScreen->format,NULL);
        SDL_FreeSurface(surfLoad);
    }
    if (surfConverted == NULL){
        printf("image file type not found");
    }
    return surfConverted;
}
bool loadFont(TTF_Font*& font, std::string path, int _size){
    font = TTF_OpenFont(path.c_str(),_size);
    if (font == NULL){
        std::cout << "font loading error at " << path << "; " << TTF_GetError();
        return 0;
    }
    return 1;
}
bool loadMusic(Mix_Music*& snd, std::string path){
    snd = Mix_LoadMUS(path.c_str());
    if (snd == NULL){
        std::cout << "font loading error at " << path << "; " << Mix_GetError();
        return 0;
    }
    return 1;
}
bool loadSound(Mix_Chunk*& snd, std::string path, std::string type){
    if (type == "wav"){
        snd = Mix_LoadWAV(path.c_str());
    }
    if (snd == NULL){
        std::cout << "font loading error at " << path << "; " << Mix_GetError();
        return 0;
    }
    return 1;
}
void drawRect(SDL_Renderer* render, int x, int y, int w, int h, bool outline){
    SDL_Rect bounds = {x,y,w,h};
    if (!outline){
        SDL_RenderFillRect(render, &bounds);
    } else {
        SDL_RenderDrawRect(render, &bounds);
    }
}
const char* toString(int i){
    std::stringstream c;
    c << i;
    return c.str().c_str();
}
void exit(){
    TTF_CloseFont(fontBody);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    window = NULL;
    renderer = NULL;
    IMG_Quit();
    TTF_Quit();
    SDL_Quit();
}

SDL_Texture* loadTexture(std::string path){
    SDL_Texture* tex = NULL;
    SDL_Surface* surfLoad = IMG_Load(path.c_str());
    if (surfLoad == NULL){
        printf("texture loading error at");
        printf(path.c_str());
    } else {
        tex = SDL_CreateTextureFromSurface(renderer,surfLoad);
        if(tex == NULL){
            printf("texture loading error with");
            printf(path.c_str());
        }
        SDL_FreeSurface(surfLoad);
    }
    return tex;
}
void resetColor(){
    SDL_SetRenderDrawColor(renderer,255,255,255,255);
}
void drawAllObjects(std::map<int,std::vector<Object*>>* objects){
    for(std::map<int,std::vector<Object*>>::iterator i = objects->begin(); i != objects->end();++i){
        for(std::vector<Object*>::iterator it = (*i).second.begin(); it != (*i).second.end(); ++it){
            (*it)->draw();
        }
    }
}
void stepAllObjects(std::map<int,std::vector<Object*>>* objects){
    for(std::map<int,std::vector<Object*>>::iterator i = objects->begin(); i != objects->end();++i){
        for(std::vector<Object*>::iterator it = (*i).second.begin(); it != (*i).second.end(); ++it){
            (*it)->o_step();
            for(int i = 0; i < 2; i++){
                if ((*it)->getAlarm(i) == 1){
                    switch(i){
                        case 0:
                        {
                            if (place_meeting((*it)->getX(),(*it)->getY(),OT_LADDER)){
                                for(std::vector<Object*>::iterator lIt = objects->at(OT_LADDER).begin(); lIt != objects->at(OT_LADDER).end(); ++lIt) {
                                    if (place_meeting((*lIt)->getX(),(*lIt)->getY(),OT_PLAYER)){
                                        if ((*lIt)->getAngle() == fmod((*it)->getDirection(),180)){
                                            (*it)->setSpeed(0);
                                            int mx = 8*((fmod(levelX,16) == 8));
                                            int my = 8*((fmod(levelY,16) == 8));
                                            if (fmod((*it)->getX()+mx,16) != 0){
                                                int test1 = (*it)->getX()+mx;
                                                int test2 = (*it)->getX()+mx;
                                                for(int u = 1; u <= 8; u++){
                                                    ++test1;
                                                    --test2;
                                                    if ((fmod(test1,16) == 0) && (fmod(test2,16) == 0)){
                                                        if (cos(degToRad((*it)->getDirection())) > 0){
                                                            (*it)->setX((*it)->getX()+8);
                                                        } else {
                                                            (*it)->setX((*it)->getX()-8);
                                                        }
                                                        break;
                                                    }
                                                    if (fmod(test1,16) == 0){
                                                        (*it)->setX(test1-mx);
                                                        break;
                                                    }
                                                    if (fmod(test2,16) == 0){
                                                        (*it)->setX(test2-mx);
                                                        break;
                                                    }
                                                }
                                            }
                                            if (fmod((*it)->getY()+my,16) != 0){
                                                int test1 = (*it)->getY()+my;
                                                int test2 = (*it)->getY()+my;
                                                for(int u = 1; u <= 8; u++){
                                                    ++test1;
                                                    --test2;
                                                    if ((fmod(test1,16) == 0) && (fmod(test2,16) == 0)){
                                                        if (sin(degToRad((*it)->getDirection())) > 0){
                                                            (*it)->setY((*it)->getY()+8);
                                                        } else {
                                                            (*it)->setY((*it)->getY()-8);
                                                        }
                                                        break;
                                                    }
                                                    if (fmod(test1,16) == 0){
                                                        (*it)->setY(test1-my);
                                                        break;
                                                    }
                                                    if (fmod(test2,16) == 0){
                                                        (*it)->setY(test2-my);
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            break;
                        }
                        default: break;
                    }
                }
            }
        }
    }
}
void clearObjects(std::map<int,std::vector<Object*>>* objects){
    for(std::map<int,std::vector<Object*>>::iterator i = objects->begin(); i != objects->end();++i){
        (*i).second.clear();
    }
    objects->clear();
}


/*---------------------------------------------------------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------------------------------------------------------*/


int main( int argc, char* args[] )
{
    initSDL(window, surfScreen);

    const Uint8* keyIs;
    bool nextLeft = true;
    bool nextUp = true;
    bool nextRight = true;
    bool nextDown = true;
    bool quit = false;

    int screen = SC_MENU;
    int level = 0;
    bool levelInit = false;
    bool menuInit = false;

    int numMoves;
    int default_movespeed = 5;
    bool anyButtonsColliding = false;

    view = {0,0,DEFAULT_WIDTH,DEFAULT_HEIGHT};
    setView(&view,0,0,DEFAULT_WIDTH,DEFAULT_HEIGHT);

    SDL_Texture* spaceBack = loadTexture("images/background/space.png");
    SDL_Texture* texMenuBack;

    loadFont(fontBody,"ttf/Weymouth Ribbon.ttf",18);

    gTexture* numMovesText = new gTexture();
    numMovesText->loadFRText(std::string("#Moves: 0"),fontBody,red);
    gTexture* idealMovesText = new gTexture();
    gTexture* levelNumText = new gTexture();
    gTexture* testText1 = new gTexture();
    gTexture* testText2 = new gTexture();

    std::map<int,std::vector<Object*>> slideObjects;
    int slide = 0;
    int transition_speedX = 0;
    int transition_speedY = 0;

    Mix_Music* sndMusic1 = NULL;
    loadMusic(sndMusic1,"mix/music/loop1.mp3");

    Mix_Chunk* sndMenuEnter = NULL;
    loadSound(sndMenuEnter,"mix/snd/misc/menuenter.wav","wav");

    Mix_Chunk* sndMenuNav = NULL;
    loadSound(sndMenuNav ,"mix/snd/misc/menunav.wav","wav");

    Mix_Chunk* sndRestart = NULL;
    loadSound(sndRestart,"mix/snd/game/restart.wav","wav");

    Mix_Chunk* sndWin = NULL;
    loadSound(sndWin,"mix/snd/game/win.wav","wav");

    Mix_Chunk* sndKeyGrab = NULL;
    loadSound(sndKeyGrab,"mix/snd/game/keygrab.wav","wav");

    Mix_Chunk* sndMove = NULL;
    loadSound(sndMove,"mix/snd/game/move1.wav","wav");

    Mix_Chunk* sndButtonPress = NULL;
    loadSound(sndButtonPress ,"mix/snd/game/buttonpress.wav","wav");



    while(!quit){
        SDL_RenderClear(renderer);
        SDL_Event e;

        if (Mix_PlayingMusic() == 0){
            Mix_PlayMusic(sndMusic1,-1);
        }

        if (screen == SC_LEVEL){
            start:
            SDL_RenderCopy(renderer,spaceBack,NULL,NULL);
            int rWidth;
            int rHeight;
            int idealNumMoves;
            bool moving;
            std::vector<Object*> players;
            std::vector<Object*> blocks;
            std::vector<Object*> goals;
            std::vector<Object*> arrows;
            std::vector<Object*> keys;
            std::vector<Object*> gates;
            std::vector<Object*> buttons;
            std::vector<Object*> ladders;
            if (!levelInit){
                numMoves = 0;
                numMovesText->loadFRText(std::string("#Moves: 0"),fontBody,red);
                levelNumText->loadFRText(std::string("Level: ")+toString(level+1),fontBody,red);
                moving = false;

                std::ifstream levelFile(std::string("levels/level")+toString(level)+std::string(".dat"));
                std::string levelStr;
                if (std::getline(levelFile,levelStr)){
                    std::istringstream strStream(levelStr);
                    std::istream_iterator<std::string> begin(strStream), end;
                    std::vector<std::string> lvlInfo(begin,end);

                    rWidth = std::atoi(lvlInfo.at(0).c_str());
                    rHeight = std::atoi(lvlInfo.at(1).c_str());
                    levelX = (DEFAULT_WIDTH/2-(16*rWidth/2)+8);
                    levelY = (DEFAULT_HEIGHT/2-(16*rHeight/2)+8);
                    idealNumMoves = std::atoi(lvlInfo.at(2).c_str());
                    if (idealNumMoves != 0){
                        idealMovesText->loadFRText(std::string("Ideal Moves: ")+toString(idealNumMoves),fontBody,red);
                    } else {
                        idealMovesText->loadFRText(std::string("Ideal Moves: -"),fontBody,red);
                    }
                    int c = 0;
                    while (std::getline(levelFile,levelStr) && c<rHeight){
                        const char* rStr = levelStr.c_str();
                        for(int i = 0; i < rWidth; i++){
                            if (rStr[i] == '0'){
                                //Object* b = new Object(OT_BLOCK,"images/obj/wall.png",0,0,0,(DEFAULT_WIDTH/2-(16*rWidth/2)+8)+(i*16),(DEFAULT_HEIGHT/2-(16*rHeight/2)+8)+(c*16),0);
                                //b->setAttribute(9,3);
                                blocks.push_back(new Object(OT_BLOCK,"images/obj/wall2.png",0,0,0,(DEFAULT_WIDTH/2-(16*rWidth/2)+8)+(i*16)+slide*(transition_speedX != 0),(DEFAULT_HEIGHT/2-(16*rHeight/2)+8)+(c*16)+slide*(transition_speedY != 0),0));
                            }
                            else if (rStr[i] == 'p'){
                                players.push_back(new Object(OT_PLAYER,"images/obj/player.png",0,0,0,(DEFAULT_WIDTH/2-(16*rWidth/2)+8)+(i*16)+slide*(transition_speedX != 0),(DEFAULT_HEIGHT/2-(16*rHeight/2)+8)+(c*16)+slide*(transition_speedY != 0),0));
                            }
                            else if (rStr[i] == 'g'){
                                goals.push_back(new Object(OT_GOAL,"images/obj/coin.png",255,255,255,(DEFAULT_WIDTH/2-(16*rWidth/2)+8)+(i*16)+slide*(transition_speedX != 0),(DEFAULT_HEIGHT/2-(16*rHeight/2)+8)+(c*16)+slide*(transition_speedY != 0),0));
                            }
                            else if (rStr[i] == '!'){
                                arrows.push_back(new Object(OT_ARROW,"images/obj/arrow.png",255,255,255,(DEFAULT_WIDTH/2-(16*rWidth/2)+8)+(i*16)+slide*(transition_speedX != 0),(DEFAULT_HEIGHT/2-(16*rHeight/2)+8)+(c*16)+slide*(transition_speedY != 0),0));
                                arrows.back()->setAttribute(AT_TYPE,AT_TYPE_ARROW);
                                arrows.back()->setAngle(0);
                            }
                            else if (rStr[i] == '@'){
                                arrows.push_back(new Object(OT_ARROW,"images/obj/arrow.png",255,255,255,(DEFAULT_WIDTH/2-(16*rWidth/2)+8)+(i*16)+slide*(transition_speedX != 0),(DEFAULT_HEIGHT/2-(16*rHeight/2)+8)+(c*16)+slide*(transition_speedY != 0),0));
                                arrows.back()->setAttribute(AT_TYPE,AT_TYPE_ARROW);
                                arrows.back()->setAngle(90);
                            }
                            else if (rStr[i] == '#'){
                                arrows.push_back(new Object(OT_ARROW,"images/obj/arrow.png",255,255,255,(DEFAULT_WIDTH/2-(16*rWidth/2)+8)+(i*16)+slide*(transition_speedX != 0),(DEFAULT_HEIGHT/2-(16*rHeight/2)+8)+(c*16)+slide*(transition_speedY != 0),0));
                                arrows.back()->setAttribute(AT_TYPE,AT_TYPE_ARROW);
                                arrows.back()->setAngle(180);
                            }
                            else if (rStr[i] == '$'){
                                arrows.push_back(new Object(OT_ARROW,"images/obj/arrow.png",255,255,255,(DEFAULT_WIDTH/2-(16*rWidth/2)+8)+(i*16)+slide*(transition_speedX != 0),(DEFAULT_HEIGHT/2-(16*rHeight/2)+8)+(c*16)+slide*(transition_speedY != 0),0));
                                arrows.back()->setAttribute(AT_TYPE,AT_TYPE_ARROW);
                                arrows.back()->setAngle(270);
                            }
                            else if (rStr[i] == 'a'){
                                keys.push_back(new Object(OT_KEY,"images/obj/key1.png",255,255,255,(DEFAULT_WIDTH/2-(16*rWidth/2)+8)+(i*16)+slide*(transition_speedX != 0),(DEFAULT_HEIGHT/2-(16*rHeight/2)+8)+(c*16)+slide*(transition_speedY != 0),0));
                                keys.back()->setAttribute(AT_TYPE,AT_TYPE_KEY);
                            }
                            else if (rStr[i] == 'b'){
                                keys.push_back(new Object(OT_KEY,"images/obj/key2.png",255,255,255,(DEFAULT_WIDTH/2-(16*rWidth/2)+8)+(i*16)+slide*(transition_speedX != 0),(DEFAULT_HEIGHT/2-(16*rHeight/2)+8)+(c*16)+slide*(transition_speedY != 0),0));
                                keys.back()->setAttribute(AT_TYPE,AT_TYPE_KEY);
                                keys.back()->setAttribute(AT_ID,AT_ID_1);
                            }
                            else if (rStr[i] == 'c'){
                                keys.push_back(new Object(OT_KEY,"images/obj/key3.png",255,255,255,(DEFAULT_WIDTH/2-(16*rWidth/2)+8)+(i*16)+slide*(transition_speedX != 0),(DEFAULT_HEIGHT/2-(16*rHeight/2)+8)+(c*16)+slide*(transition_speedY != 0),0));
                                keys.back()->setAttribute(AT_TYPE,AT_TYPE_KEY);
                                keys.back()->setAttribute(AT_ID,AT_ID_2);
                            }
                            else if (rStr[i] == 'A'){
                                gates.push_back(new Object(OT_GATE,"images/obj/gate1.png",255,255,255,(DEFAULT_WIDTH/2-(16*rWidth/2)+8)+(i*16)+slide*(transition_speedX != 0),(DEFAULT_HEIGHT/2-(16*rHeight/2)+8)+(c*16)+slide*(transition_speedY != 0),0));
                                gates.back()->setAttribute(AT_TYPE,AT_TYPE_GATE);//type
                            }
                            else if (rStr[i] == 'B'){
                                gates.push_back(new Object(OT_GATE,"images/obj/gate2.png",255,255,255,(DEFAULT_WIDTH/2-(16*rWidth/2)+8)+(i*16)+slide*(transition_speedX != 0),(DEFAULT_HEIGHT/2-(16*rHeight/2)+8)+(c*16)+slide*(transition_speedY != 0),0));
                                gates.back()->setAttribute(AT_TYPE,AT_TYPE_GATE);
                                gates.back()->setAttribute(AT_ID,AT_ID_1);
                            }
                            else if (rStr[i] == 'C'){
                                gates.push_back(new Object(OT_GATE,"images/obj/gate3.png",255,255,255,(DEFAULT_WIDTH/2-(16*rWidth/2)+8)+(i*16)+slide*(transition_speedX != 0),(DEFAULT_HEIGHT/2-(16*rHeight/2)+8)+(c*16)+slide*(transition_speedY != 0),0));
                                gates.back()->setAttribute(AT_TYPE,AT_TYPE_GATE);
                                gates.back()->setAttribute(AT_ID,AT_ID_2);
                            }
                            else if (rStr[i] == 'z'){
                                buttons.push_back(new Object(OT_BUTTON,"images/obj/button1.png",255,255,255,(DEFAULT_WIDTH/2-(16*rWidth/2)+8)+(i*16)+slide*(transition_speedX != 0),(DEFAULT_HEIGHT/2-(16*rHeight/2)+8)+(c*16)+slide*(transition_speedY != 0),0));
                                buttons.back()->setAttribute(AT_TYPE,AT_TYPE_BUTTON);
                            }
                            else if (rStr[i] == 'y'){
                                buttons.push_back(new Object(OT_BUTTON,"images/obj/button2.png",255,255,255,(DEFAULT_WIDTH/2-(16*rWidth/2)+8)+(i*16)+slide*(transition_speedX != 0),(DEFAULT_HEIGHT/2-(16*rHeight/2)+8)+(c*16)+slide*(transition_speedY != 0),0));
                                buttons.back()->setAttribute(AT_TYPE,AT_TYPE_BUTTON);
                                buttons.back()->setAttribute(AT_ID,AT_ID_1);
                            }
                            else if (rStr[i] == '='){
                                ladders.push_back(new Object(OT_LADDER,"images/obj/ladder.png",255,255,255,(DEFAULT_WIDTH/2-(16*rWidth/2)+8)+(i*16)+slide*(transition_speedX != 0),(DEFAULT_HEIGHT/2-(16*rHeight/2)+8)+(c*16)+slide*(transition_speedY != 0),0));
                                ladders.back()->setAttribute(AT_TYPE,AT_TYPE_LADDER);
                                ladders.back()->setAngle(0);
                            }
                            else if (rStr[i] == 'i'){
                                ladders.push_back(new Object(OT_LADDER,"images/obj/ladder.png",255,255,255,(DEFAULT_WIDTH/2-(16*rWidth/2)+8)+(i*16)+slide*(transition_speedX != 0),(DEFAULT_HEIGHT/2-(16*rHeight/2)+8)+(c*16)+slide*(transition_speedY != 0),0));
                                ladders.back()->setAttribute(AT_TYPE,AT_TYPE_LADDER);
                                ladders.back()->setAngle(90);
                            }
                        }
                        c++;
                    }

                    for(std::vector<Object*>::iterator pIt = players.begin(); pIt != players.end(); ++pIt) {
                        (*pIt)->setCollideTypes(std::vector<int>{OT_BLOCK,OT_PLAYER,OT_GATE});
                    }


                    objects.insert(std::pair<int,std::vector<Object*>>(OT_PLAYER,players));
                    objects.insert(std::pair<int,std::vector<Object*>>(OT_BLOCK,blocks));
                    objects.insert(std::pair<int,std::vector<Object*>>(OT_GOAL,goals));
                    objects.insert(std::pair<int,std::vector<Object*>>(OT_ARROW,arrows));
                    objects.insert(std::pair<int,std::vector<Object*>>(OT_KEY,keys));
                    objects.insert(std::pair<int,std::vector<Object*>>(OT_GATE,gates));
                    objects.insert(std::pair<int,std::vector<Object*>>(OT_BUTTON,buttons));
                    objects.insert(std::pair<int,std::vector<Object*>>(OT_LADDER,ladders));

                    for(std::vector<Object*>::iterator bIt = objects.at(OT_BLOCK).begin(); bIt != objects.at(OT_BLOCK).end(); ++bIt) {
                        (*bIt)->setAttribute(AT_BORDER,3);
                    }
                    for(std::vector<Object*>::iterator gIt = objects.at(OT_GATE).begin(); gIt != objects.at(OT_GATE).end(); ++gIt) {
                        (*gIt)->setAttribute(AT_BORDER,2);
                    }

                    levelInit = true;
                }
                else {
                    screen = SC_MENU;
                    continue;
                }
            }
            if (slide != 0){
                slide -= (transition_speedX+transition_speedY);
                for(std::map<int,std::vector<Object*>>::iterator i = slideObjects.begin(); i != slideObjects.end();++i){
                    for(std::vector<Object*>::iterator it = (*i).second.begin(); it != (*i).second.end(); ++it){
                        (*it)->setX((*it)->getX()-transition_speedX);
                        (*it)->setY((*it)->getY()-transition_speedY);
                    }
                }
                for(std::map<int,std::vector<Object*>>::iterator i = objects.begin(); i != objects.end();++i){
                    for(std::vector<Object*>::iterator it = (*i).second.begin(); it != (*i).second.end(); ++it){
                        (*it)->setX((*it)->getX()-transition_speedX);
                        (*it)->setY((*it)->getY()-transition_speedY);
                    }
                }
                if (std::abs(slide) <= 5){
                    slide = 0;
                    slideObjects.clear();
                }
                drawAllObjects(&slideObjects);
            }

            resetColor();
            SDL_PumpEvents();
            keyIs = SDL_GetKeyboardState(NULL);

            int win = true;
            for(std::vector<Object*>::iterator it = (objects.at(OT_GOAL)).begin(); it != (objects.at(OT_GOAL)).end(); ++it){
                std::vector<Object*> objVector = place_meeting_return((*it)->getX(),(*it)->getY(),OT_PLAYER);
                if (objVector.size() == 0){
                    win = false;
                }
                else if (objVector.at(0)->getSpeed() != 0){
                    win = false;
                }
            }
            if (win == true){
                Mix_PlayChannel(-1,sndWin,0);
                if (levelInit){
                    int r = (std::rand()%4 + 1);
                    if (r == 1){
                        slide = 480;
                        transition_speedX = 0;
                        transition_speedY = 48;
                    }
                    else if (r == 2){
                        slide = 640;
                        transition_speedX = 64;
                        transition_speedY = 0;
                    }
                    else if (r == 3){
                        slide = -640;
                        transition_speedX = -64;
                        transition_speedY = 0;
                    }
                    else {
                        slide = -480;
                        transition_speedX = 0;
                        transition_speedY = -48;
                    }
                    slideObjects = objects;
                    objects.clear();
                    levelInit = false;
                    level++;
                    SDL_Delay(400);
                    continue;
                }
            }

            int m = false;
            for(std::vector<Object*>::iterator pIt = objects.at(OT_PLAYER).begin(); pIt != objects.at(OT_PLAYER).end();) {
                if ((*pIt)->getSpeed() != 0 && (((*pIt)->getX() < view.x+view.w+(*pIt)->getWidth()) && ((*pIt)->getX() > view.x-(*pIt)->getWidth()) && ((*pIt)->getY() < view.y+view.h+(*pIt)->getHeight()) && ((*pIt)->getY() > view.y-(*pIt)->getHeight()))){
                    m = true;
                    pIt++;
                }
                else if (!(((*pIt)->getX() < view.x+view.w+(*pIt)->getWidth()) && ((*pIt)->getX() > view.x-(*pIt)->getWidth()) && ((*pIt)->getY() < view.y+view.h+(*pIt)->getHeight()) && ((*pIt)->getY() > view.y-(*pIt)->getHeight())) && (slide == 0)){
                    if (objects.at(OT_PLAYER).size() > 1){
                        delete (*pIt);
                        pIt = (objects.at(OT_PLAYER)).erase(pIt);
                    } else {
                        pIt++;
                        if (levelInit){
                            Mix_PlayChannel(-1,sndRestart,0);
                            objects.clear();
                            levelInit = false;
                            goto start;
                        }
                    }
                } else {
                    pIt++;
                }
            }
            if (slide != 0){
                m = true;
            }
            if (m == true){
                if (moving == false){
                    Mix_PlayChannel(-1,sndMove,0);
                    numMoves++;
                    numMovesText->loadFRText(std::string("#Moves: ")+toString(numMoves),fontBody,red);
                }
                moving = true;
            }
            if (m == false){
                moving = false;
            }
            if (moving == false){
                if (keyIs[SDL_SCANCODE_LEFT] && nextLeft){
                    nextLeft = false;
                    for(std::vector<Object*>::iterator pIt = objects.at(OT_PLAYER).begin(); pIt != objects.at(OT_PLAYER).end(); ++pIt) {
                            if (!(place_meeting((*pIt)->getX(),(*pIt)->getY(),OT_ARROW))){
                                if (!(place_meeting((*pIt)->getX(),(*pIt)->getY(),OT_LADDER))){
                                    (*pIt)->setDirection(180);
                                    (*pIt)->setSpeed(default_movespeed);
                                } else {
                                    for(std::vector<Object*>::iterator lIt = objects.at(OT_LADDER).begin(); lIt != objects.at(OT_LADDER).end(); ++lIt) {
                                        if (place_meeting((*lIt)->getX(),(*lIt)->getY(),OT_PLAYER)){
                                            (*pIt)->setDirection(180);
                                            (*pIt)->setSpeed(default_movespeed);
                                            if ((*lIt)->getAngle() == 0){
                                                (*pIt)->setAlarm(0,3);
                                            }
                                        }
                                    }
                                }
                            } else {
                                for(std::vector<Object*>::iterator aIt = objects.at(OT_ARROW).begin(); aIt != objects.at(OT_ARROW).end(); ++aIt) {
                                    if (place_meeting((*aIt)->getX(),(*aIt)->getY(),OT_PLAYER)){
                                        if ((*aIt)->getAngle() == 180){
                                            (*pIt)->setDirection(180);
                                            (*pIt)->setSpeed(default_movespeed);
                                        }
                                    }
                                }
                            }
                    }
                }
                else if (keyIs[SDL_SCANCODE_UP] && nextUp){
                    nextUp = false;
                    for(std::vector<Object*>::iterator pIt = objects.at(OT_PLAYER).begin(); pIt != objects.at(OT_PLAYER).end(); ++pIt) {
                            if (!(place_meeting((*pIt)->getX(),(*pIt)->getY(),OT_ARROW))){
                                if (!(place_meeting((*pIt)->getX(),(*pIt)->getY(),OT_LADDER))){
                                    (*pIt)->setDirection(270);
                                    (*pIt)->setSpeed(default_movespeed);
                                } else {
                                    for(std::vector<Object*>::iterator lIt = objects.at(OT_LADDER).begin(); lIt != objects.at(OT_LADDER).end(); ++lIt) {
                                        if (place_meeting((*lIt)->getX(),(*lIt)->getY(),OT_PLAYER)){
                                            (*pIt)->setDirection(270);
                                            (*pIt)->setSpeed(default_movespeed);
                                            if ((*lIt)->getAngle() == 90){
                                                (*pIt)->setAlarm(0,3);
                                            }
                                        }
                                    }
                                }
                            } else {
                                for(std::vector<Object*>::iterator aIt = objects.at(OT_ARROW).begin(); aIt != objects.at(OT_ARROW).end(); ++aIt) {
                                    if (place_meeting((*aIt)->getX(),(*aIt)->getY(),OT_PLAYER)){
                                        if ((*aIt)->getAngle() == 270){
                                            (*pIt)->setDirection(270);
                                            (*pIt)->setSpeed(default_movespeed);
                                        }
                                    }
                                }
                            }
                    }
                }
                else if (keyIs[SDL_SCANCODE_RIGHT] && nextRight){
                    nextRight = false;
                    for(std::vector<Object*>::iterator pIt = objects.at(OT_PLAYER).begin(); pIt != objects.at(OT_PLAYER).end(); ++pIt) {
                            if (!(place_meeting((*pIt)->getX(),(*pIt)->getY(),OT_ARROW))){
                                if (!(place_meeting((*pIt)->getX(),(*pIt)->getY(),OT_LADDER))){
                                    (*pIt)->setDirection(0);
                                    (*pIt)->setSpeed(default_movespeed);
                                } else {
                                    for(std::vector<Object*>::iterator lIt = objects.at(OT_LADDER).begin(); lIt != objects.at(OT_LADDER).end(); ++lIt) {
                                        if (place_meeting((*lIt)->getX(),(*lIt)->getY(),OT_PLAYER)){
                                            (*pIt)->setDirection(0);
                                            (*pIt)->setSpeed(default_movespeed);
                                            if ((*lIt)->getAngle() == 0){
                                                (*pIt)->setAlarm(0,3);
                                            }
                                        }
                                    }
                                }
                            } else {
                                for(std::vector<Object*>::iterator aIt = objects.at(OT_ARROW).begin(); aIt != objects.at(OT_ARROW).end(); ++aIt) {
                                    if (place_meeting((*aIt)->getX(),(*aIt)->getY(),OT_PLAYER)){
                                        if ((*aIt)->getAngle() == 0){
                                            (*pIt)->setDirection(0);
                                            (*pIt)->setSpeed(default_movespeed);
                                        }
                                    }
                                }
                            }
                    }
                }
                else if (keyIs[SDL_SCANCODE_DOWN] && nextDown){
                    nextDown = false;
                    for(std::vector<Object*>::iterator pIt = objects.at(OT_PLAYER).begin(); pIt != objects.at(OT_PLAYER).end(); ++pIt) {
                            if (!(place_meeting((*pIt)->getX(),(*pIt)->getY(),OT_ARROW))){
                                if (!(place_meeting((*pIt)->getX(),(*pIt)->getY(),OT_LADDER))){
                                    (*pIt)->setDirection(90);
                                    (*pIt)->setSpeed(default_movespeed);
                                } else {
                                    for(std::vector<Object*>::iterator lIt = objects.at(OT_LADDER).begin(); lIt != objects.at(OT_LADDER).end(); ++lIt) {
                                        if (place_meeting((*lIt)->getX(),(*lIt)->getY(),OT_PLAYER)){
                                            (*pIt)->setDirection(90);
                                            (*pIt)->setSpeed(default_movespeed);
                                            if ((*lIt)->getAngle() == 90){
                                                (*pIt)->setAlarm(0,3);
                                            }
                                        }
                                    }
                                }
                            } else {
                                for(std::vector<Object*>::iterator aIt = objects.at(OT_ARROW).begin(); aIt != objects.at(OT_ARROW).end(); ++aIt) {
                                    if (place_meeting((*aIt)->getX(),(*aIt)->getY(),OT_PLAYER)){
                                        if ((*aIt)->getAngle() == 90){
                                            (*pIt)->setDirection(90);
                                            (*pIt)->setSpeed(default_movespeed);
                                        }
                                    }
                                }
                            }
                    }
                }
            } else {
                for(std::vector<Object*>::iterator pIt = objects.at(OT_PLAYER).begin(); pIt != objects.at(OT_PLAYER).end(); ++pIt) {
                    if (place_meeting((*pIt)->getX(),(*pIt)->getY(),OT_LADDER)){
                        for(std::vector<Object*>::iterator lIt = objects.at(OT_LADDER).begin(); lIt != objects.at(OT_LADDER).end(); ++lIt) {
                            if (place_meeting((*lIt)->getX(),(*lIt)->getY(),OT_PLAYER)){
                                if ((*lIt)->getAngle() == fmod((*pIt)->getDirection(),180)){
                                    if ((*pIt)->getAlarm(0) == 0){
                                        (*pIt)->setAlarm(0,1);
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (!keyIs[SDL_SCANCODE_LEFT]) { nextLeft = true; }
            if (!keyIs[SDL_SCANCODE_UP]) { nextUp = true; }
            if (!keyIs[SDL_SCANCODE_RIGHT]) { nextRight = true; }
            if (!keyIs[SDL_SCANCODE_DOWN]) { nextDown = true; }

            numMovesText->renderCenter(8,8,CT_TOPLEFT);
            idealMovesText->renderCenter(DEFAULT_WIDTH-8,8,CT_TOPRIGHT);
            levelNumText->renderCenter(DEFAULT_WIDTH/2,8,CT_TOPMIDDLE);

            stepAllObjects(&objects);
            drawAllObjects(&objects);
            //->draw();

            SDL_RenderSetViewport(renderer, &view);

            for(std::vector<Object*>::iterator kIt = (objects.at(OT_KEY)).begin(); kIt != (objects.at(OT_KEY)).end();){
                if (place_meeting((*kIt)->getX(),(*kIt)->getY(),OT_PLAYER)){
                    for(std::vector<Object*>::iterator gIt = (objects.at(OT_GATE)).begin(); gIt != (objects.at(OT_GATE)).end();++gIt){
                        if ((*kIt)->getAttribute(AT_ID) == (*gIt)->getAttribute(AT_ID)){
                            (*gIt)->addAttribute(AT_COLLISION,0);
                            (*gIt)->addAttribute(AT_VISIBLE,0);
                        }
                    }
                    for(std::vector<Object*>::iterator kIt2 = (objects.at(OT_KEY)).begin(); kIt2 != (objects.at(OT_KEY)).end();){
                        if (((*kIt2)->getAttribute(AT_ID) == (*kIt)->getAttribute(AT_ID)) && ((*kIt) != (*kIt2))){
                            delete (*kIt2);
                            kIt2 = (objects.at(OT_KEY)).erase(kIt2);
                            Mix_PlayChannel(-1,sndKeyGrab,0);
                            if (kIt > kIt2){
                                --kIt;
                            }
                        } else {
                            ++kIt2;
                        }
                    }
                    delete (*kIt);
                    kIt = (objects.at(OT_KEY)).erase(kIt);
                    Mix_PlayChannel(-1,sndKeyGrab,0);
                } else {
                    ++kIt;
                }
            }

            bool anyButtonsCollidingStep = false;
            for(std::vector<Object*>::iterator bIt = (objects.at(OT_BUTTON)).begin(); bIt != (objects.at(OT_BUTTON)).end(); ++bIt){
                bool colliding = false;
                for(std::vector<Object*>::iterator pIt = (objects.at(OT_PLAYER)).begin(); pIt != (objects.at(OT_PLAYER)).end(); ++pIt){
                    if ((*pIt)->getSpeed()){
                        for(int i = 1; i <= (*pIt)->getSpeed(); i++){
                            if ((*pIt)->place_meeting((*pIt)->getX()+i*cos(degToRad((*pIt)->getDirection())),(*pIt)->getY()+i*sin(degToRad((*pIt)->getDirection())),(*bIt))){
                                colliding = true;
                                anyButtonsCollidingStep = true;
                                if (anyButtonsColliding == false){
                                    anyButtonsColliding = true;
                                    Mix_PlayChannel(-1,sndButtonPress,0);
                                }
                            }
                        }
                    } else {
                        if ((*pIt)->place_meeting((*bIt))){
                            colliding = true;
                            anyButtonsCollidingStep = true;
                            if (anyButtonsColliding == false){
                                anyButtonsColliding = true;
                                Mix_PlayChannel(-1,sndButtonPress,0);
                            }
                        }
                    }
                }
                if (colliding){
                    if ((*bIt)->getAttribute(AT_PUSHED) == 0){
                        for(std::vector<Object*>::iterator gIt = (objects.at(OT_GATE)).begin(); gIt != (objects.at(OT_GATE)).end();++gIt){
                            if ((*bIt)->getAttribute(AT_ID) == (*gIt)->getAttribute(AT_ID)){
                                (*gIt)->addAttribute(AT_COLLISION,0);
                                (*gIt)->addAttribute(AT_VISIBLE,0);
                            }
                        }
                        (*bIt)->setAttribute(AT_PUSHED,1);
                    }
                } else {
                    if ((*bIt)->getAttribute(AT_PUSHED) == 1){
                        (*bIt)->setAttribute(AT_PUSHED,0);
                        for(std::vector<Object*>::iterator gIt = (objects.at(OT_GATE)).begin(); gIt != (objects.at(OT_GATE)).end();++gIt){
                            if ((*bIt)->getAttribute(AT_ID) == (*gIt)->getAttribute(AT_ID)){
                                (*gIt)->addAttribute(AT_COLLISION,1);
                                (*gIt)->addAttribute(AT_VISIBLE,1);
                            }
                        }
                    }
                }
            }
            if (anyButtonsCollidingStep == false){
                anyButtonsColliding = false;
            }




            while(SDL_PollEvent(&e) != 0){
                if (e.type == SDL_QUIT){
                    quit = true;
                }
                switch(e.type){
                    case SDL_KEYDOWN:
                        switch(e.key.keysym.sym){
                            case SDLK_r:
                                if (levelInit){
                                    Mix_PlayChannel(-1,sndRestart,0);
                                    objects.clear();
                                    levelInit = false;
                                    break;
                                }
                            case SDLK_END:
                                if (levelInit){
                                    objects.clear();
                                    levelInit = false;
                                    level+=5;
                                    break;
                                }
                            case SDLK_PAGEUP:
                                if (levelInit){
                                    objects.clear();
                                    levelInit = false;
                                    level++;
                                    break;
                                }
                            case SDLK_PAGEDOWN:
                                if (levelInit){
                                    objects.clear();
                                    levelInit = false;
                                    level--;
                                    break;
                                }
                            case SDLK_SPACE:
                                if (levelInit){
                                    objects.clear();
                                    levelInit = false;
                                    level=14;
                                    break;
                                }
                            default: break;
                        }
                    default: break;
                }
            }
            //
        }
        else if (screen == SC_MENU){
            int arrowPos;
            Object* menuArrow;
            if (!menuInit){
                arrowPos = 0;
                texMenuBack = loadTexture("images/menu/titlescreen.png");
                menuArrow = new Object(OT_SPECIAL,"images/menu/titlearrow.png",0,0,0,237,240,0);
                menuInit = true;
            }

            menuArrow->setY(210+arrowPos*57);
            if (arrowPos == 0){
                menuArrow->setX(238);
            } else if (arrowPos == 1){
                menuArrow->setX(118);
            } else if (arrowPos == 2){
                menuArrow->setX(127);
            }


            SDL_RenderCopy(renderer,texMenuBack,NULL,NULL);
            menuArrow->draw();

            SDL_PumpEvents();
            keyIs = SDL_GetKeyboardState(NULL);

            while(SDL_PollEvent(&e) != 0){
                if (e.type == SDL_QUIT){
                    quit = true;
                }
                switch(e.type){
                    case SDL_KEYDOWN:
                        switch(e.key.keysym.sym){
                            case SDLK_RETURN:
                                {
                                    Mix_PlayChannel(-1,sndMenuEnter,0);
                                    if (arrowPos == 0){
                                        screen = SC_LEVEL;
                                        level = 0;
                                        break;
                                    }
                                    if (arrowPos == 1){
                                        printf("Error: level select not yet implemented.\n");
                                    }
                                    if (arrowPos == 2){
                                        printf("Error: level editor not yet implemented.\n");
                                    }
                                    break;
                                }
                            case SDLK_UP:
                                {
                                    Mix_PlayChannel(-1,sndMenuNav,0);
                                    arrowPos--;
                                    if (arrowPos == -1){
                                        arrowPos = 2;
                                    }
                                    break;
                                }
                            case SDLK_DOWN:
                                {
                                    Mix_PlayChannel(-1,sndMenuNav,0);
                                    arrowPos++;
                                    if (arrowPos == 3){
                                        arrowPos = 0;
                                    }
                                    break;
                                }
                            case SDLK_SPACE:
                                {
                                    screen = SC_LEVEL;
                                    level = 14;
                                    break;
                                }
                            default: break;
                        }
                    default: break;
                }
            }
        }
        SDL_RenderPresent(renderer);
        SDL_Delay(17+(1000*keyIs[SDL_SCANCODE_SPACE]));
    }
    Mix_FreeMusic(sndMusic1);
    Mix_FreeChunk(sndKeyGrab);
    Mix_FreeChunk(sndMenuEnter);
    Mix_FreeChunk(sndMenuNav);
    Mix_FreeChunk(sndMove);
    Mix_FreeChunk(sndRestart);
    Mix_FreeChunk(sndWin);
    SDL_DestroyTexture(spaceBack);
    SDL_DestroyTexture(texMenuBack);
    exit();
    return 0;
}

bool place_meeting(float x, float y, int obj_type){
    for(std::vector<Object*>::iterator it = (objects.at(obj_type)).begin(); it != (objects.at(obj_type)).end(); ++it){
        if ((*it)->contains(x,y)){
            return true;
        }
    }
    return false;
}
std::vector<Object*> place_meeting_return(float x, float y, int obj_type){
    std::vector<Object*> objVector;
    for(std::vector<Object*>::iterator it = (objects.at(obj_type)).begin(); it != (objects.at(obj_type)).end(); ++it){
        if ((*it)->contains(x,y)){
            objVector.push_back(*it);
        }
    }
    return objVector;
}

bool place_meetingf(float x, float y, int obj_type){
    return place_meeting(x,y,obj_type);
}

bool place_meeting(float x, float y, float w, float h, int obj_type){
        for(std::vector<Object*>::iterator it = (objects.at(obj_type)).begin(); it != (objects.at(obj_type)).end(); ++it){
            if ((*it)->contains(x,y)){
                    return true;
            } else if ((*it)->contains(x-w/2,y)){
                    return true;
            } else if ((*it)->contains(x+w/2,y)){
                    return true;
            } else if ((*it)->contains(x,y-h/2)){
                    return true;
            } else if ((*it)->contains(x,y+h/2)){
                    return true;
            }
        }

    return false;
}

float degToRad(float dir){
    return dir*M_PI/180;
}
