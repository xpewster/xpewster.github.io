#ifndef GTEXTURE_H
#define GTEXTURE_H
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <string>
#include <globals.h>

class gTexture
{
    public:
        gTexture();
        virtual ~gTexture();

        bool loadFile(std::string path, bool colorKey, Uint8 r, Uint8 g, Uint8 b);
        bool loadFRText(std::string str, TTF_Font* font, SDL_Color col);//load from rendered text

        void free();

        void render(int x, int y);
        void renderCenter(int x, int y, int centerType);
        void renderEx(int x, int y, double angle, SDL_Point* center, SDL_RendererFlip flip);

        void setWidth(Uint8 width);
        void setHeight(Uint8 height);
        Uint8 getWidth();
        Uint8 getHeight();

        SDL_Texture* sdlTex;

    protected:
        typedef gTexture super;

    private:

        Uint8 width;
        Uint8 height;


};

#endif // GTEXTURE_H
