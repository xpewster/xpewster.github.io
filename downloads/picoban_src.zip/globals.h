#ifndef GLOBALS_H
#define GLOBALS_H
#define _USE_MATH_DEFINES
#include <math.h>
#include <cmath>
#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>
#include <vector>
#include <map>

class Object;

extern SDL_Renderer* renderer;
extern TTF_Font* fontBody;
extern int levelX;
extern int levelY;

extern const char* toString(int i);
extern bool place_meeting(float x, float y, int obj_type);
extern std::vector<Object*> place_meeting_return(float x, float y, int obj_type);
extern bool place_meetingf(float x, float y, int obj_type);
extern bool place_meeting(float x, float y, float w, float h, int obj_type);
extern float degToRad(float dir);

extern std::map<int,std::vector<Object*>> objects;

#endif // GLOBALS_H
