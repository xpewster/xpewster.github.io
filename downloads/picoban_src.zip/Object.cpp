#include "Object.h"
#include <math.h>
#include <cmath>
#include <algorithm>
#include <array>
#include <iostream>

Object::Object()
{
    init();
}

Object::~Object()
{
    if (tex != NULL){
        delete tex;
    }
    tex = NULL;
}
Object::Object(int type, float x, float y, Uint8 width, Uint8 height, int depth){
    init();
    this->type = type;
    this->width = width;
    this->height = height;
    this->x = x;
    this->y = y;
    this->depth = depth;
}
Object::Object(int type, std::string path, float x, float y, int depth){
    init();
    this->type = type;
    tex = new gTexture();
    Object::loadTexture(path);
    this->x = x;
    this->y = y;
    this->depth = depth;
}
Object::Object(int type, std::string path, Uint8 r, Uint8 g, Uint8 b, float x, float y, int depth){
    init();
    this->type = type;
    tex = new gTexture();
    Object::loadTextureColorKey(path,r,g,b);
    this->x = x;
    this->y = y;
    this->depth = depth;
}

void Object::init(){
    tex = NULL;
    sprInd = 0;
    width = 0;
    height = 0;
    x = 0;
    y = 0;
    speed = 0;
    dir = 0;
    depth = 0;
    attribute1 = 0;
    attribute2 = 0;
    attribute3 = 0;
    attribute4 = 0;
    attribute5 = 0;
    attribute9 = 0;
    angle = 0;
    for(int i = 0; i < 10; ++i){
        alarm[i] = 0;
    }
}
int Object::getType(){
    return type;
}
void Object::setAttribute(int num, int value){
    if (num == 1){
        attribute1 = value;
    }
    else if (num == 2){
        attribute2 = value;
    }
    else if (num == 3){
        attribute3 = value;
    }
    else if (num == 4){
        attribute4 = value;
    }
    else if (num == 5){
        attribute5 = value;
    }
    else if (num == 9){
        attribute9 = value;
        if (attribute9 > 0){
            if (place_meetingf(x+16,y,type)){
                attribute9array[0] = 1;
            }
            if (place_meetingf(x,y-16,type)){
                attribute9array[1] = 1;
            }
            if (place_meetingf(x-16,y,type)){
                attribute9array[2] = 1;
            }
            if (place_meetingf(x,y+16,type)){
                attribute9array[3] = 1;
            }
            if (place_meetingf(x+16,y-16,type)){
                attribute9array[4] = 1;
            }
            if (place_meetingf(x-16,y-16,type)){
                attribute9array[5] = 1;
            }
            if (place_meetingf(x-16,y+16,type)){
                attribute9array[6] = 1;
            }
            if (place_meetingf(x+16,y+16,type)){
                attribute9array[7] = 1;
            }
        }
    }
}
void Object::addAttribute(int num, int subtract){
    if (!(subtract)){
        if (num == 1){
            attribute1++;
        }
        else if (num == 2){
            attribute2++;
        }
        else if (num == 3){
            attribute3++;
        }
        else if (num == 4){
            attribute4++;
        }
        else if (num == 5){
            attribute5++;
        }
    }
    else {
        if (num == 1){
            attribute1--;
        }
        else if (num == 2){
            attribute2--;
        }
        else if (num == 3){
            attribute3--;
        }
        else if (num == 4){
            attribute4--;
        }
        else if (num == 5){
            attribute5--;
        }
    }
}
int Object::getAttribute(int num){
    if (num == 1){
        return attribute1;
    }
    else if (num == 2){
        return attribute2;
    }
    else if (num == 3){
        return attribute3;
    }
    else if (num == 4){
        return attribute4;
    }
    else if (num == 5){
        return attribute5;
    }
}
void Object::setCollideTypes(std::vector<int> types){
    collideTypes.assign(types.begin(),types.end());
}
void Object::addCollideType(int type){
    if (!(std::find(collideTypes.begin(),collideTypes.end(),type) != collideTypes.end())){
        collideTypes.push_back(type);
    }
}
bool Object::removeCollideType(int type){
    if (std::find(collideTypes.begin(),collideTypes.end(),type) != collideTypes.end()){
        collideTypes.erase(std::find(collideTypes.begin(),collideTypes.end(),type));
        return 1;
    }

    return 0;
}
std::vector<int>* Object::getCollideTypes(){
    return &collideTypes;
}

bool Object::loadTexture(std::string path){
    if ((tex->loadFile(path,false,0xFF,0xFF,0xFF)) == false) {
        return 0;
    }
    width = tex->getWidth();
    height = tex->getHeight();
    return 1;
}

bool Object::loadTextureColorKey(std::string path, Uint8 r, Uint8 g, Uint8 b){
    if ((tex->loadFile(path,true,r,g,b)) == false) {
        return 0;
    }
    width = tex->getWidth();
    height = tex->getHeight();
    return 1;
}


void Object::setX(float x){
    this->x = x;
}
float Object::getX(){
    return x;
}
void Object::setY(float y){
    this->y = y;
}
float Object::getY(){
    return y;
}

void Object::setSpeed(float speed){
    this->speed = speed;
}
float Object::getSpeed(){
    return speed;
}

void Object::setDirection(float dir){
    this->dir = fmod(dir,360);
}
float Object::getDirection(){
    return dir;
}

void Object::setWidth(Uint8 width){
    this->width = width;
}
Uint8 Object::getWidth(){
    return width;
}
void Object::setHeight(Uint8 height){
    this->height = height;
}
Uint8 Object::getHeight(){
    return height;
}

void Object::setSpriteIndex(Uint8 i){
    sprInd = i;
}
Uint8 Object::getSpriteIndex(){
    return sprInd;
}

void Object::setDepth(int depth){
    this->depth = depth;
}
int Object::getDepth(){
    return depth;
}
void Object::setDrawDepth(int depth){
    this->drawDepth = depth;
}
int Object::getDrawDepth(){
    return drawDepth;
}
void Object::setAngle(double ang){
    angle = ang;
}
double Object::getAngle(){
    return angle;
}
bool Object::intersects(Object* other){ //untested function
    if (((x+(width/2))<(other->getX()-((other->getWidth())/2))) ||
        ((x-(width/2))>(other->getX()+((other->getWidth())/2))) ||
        ((y+(height/2))<(other->getY()-((other->getHeight())/2))) ||
        ((y-(height/2))>(other->getY()+((other->getHeight())/2))))
        {
            return false;
        }
    return true;
}
bool Object::contains(float px, float py){
    if ((px > (x-width/2)) && (px < (x+width/2)) && (py > (y-height/2)) && (py < (y+height/2))){
        return true;
    }
    return false;
}
void Object::o_move(){
    if (dir == 0){
        x += speed;
    }
    else if (dir == 90){
        y -= speed;
    }
    else if (dir == 180){
        x -= speed;
    }
    else if (dir == 270){
        y += speed;
    }
    else {
        x += speed*cos(degToRad(dir));
        y += speed*sin(degToRad(dir));
    }
}
bool Object::oc_move(){
    if (speed > 0){
        for(int i = 1; i <= speed; i++){
            if (!place_meeting(x+cos(degToRad(dir)),y+sin(degToRad(dir)),tex,collideTypes)){
                x += cos(degToRad(dir));
                y += sin(degToRad(dir));
            } else {
                int mx = 8*((fmod(levelX,16) == 8));
                int my = 8*((fmod(levelY,16) == 8));
                if (fmod(x+mx,16) != 0){
                    int test1 = x+mx;
                    int test2 = x+mx;
                    for(int u = 1; u <= 8; u++){
                        ++test1;
                        --test2;
                        if ((fmod(test1,16) == 0) && (fmod(test2,16) == 0)){
                            if (cos(degToRad(dir)) > 0){
                                x += 8;
                            } else {
                                x -= 8;
                            }
                            break;
                        }
                        if (fmod(test1,16) == 0){
                            x = test1-mx;
                            break;
                        }
                        if (fmod(test2,16) == 0){
                            x = test2-mx;
                            break;
                        }
                    }
                }
                if (fmod(y+my,16) != 0){
                    int test1 = y+my;
                    int test2 = y+my;
                    for(int u = 1; u <= 8; u++){
                        ++test1;
                        --test2;
                        if ((fmod(test1,16) == 0) && (fmod(test2,16) == 0)){
                            if (sin(degToRad(dir)) > 0){
                                y += 8;
                            } else {
                                y -= 8;
                            }
                            break;
                        }
                        if (fmod(test1,16) == 0){
                            y = test1-my;
                            break;
                        }
                        if (fmod(test2,16) == 0){
                            y = test2-my;
                            break;
                        }
                    }
                }
                speed = 0;
                return 0;
            }
        }
    }
    return 1;
}
void Object::setAlarm(int alarm, int time){
    this->alarm[alarm] = time+1;
}
int Object::getAlarm(int alarm){
    return this->alarm[alarm];
}
void Object::alarm_step(){
    for(int i = 0; i < 10; ++i){
        if (alarm[i] > 0) {
            alarm[i]--;
        }
    }
}
void Object::o_step(){
    alarm_step();
    oc_move();
}
bool Object::place_meeting(float x, float y, gTexture* tex, std::vector<int> collideTypes){ //imperfect
    for(std::map<int,std::vector<Object*>>::iterator i = objects.begin(); i != objects.end();++i){
        for(std::vector<Object*>::iterator it = (*i).second.begin(); it != (*i).second.end(); ++it){
            if (!((*it) == this)){
                bool intersects = false;
                if ((*it)->contains(x-tex->getWidth()/2,y-tex->getHeight()/2)){
                    intersects = true;
                } else if ((*it)->contains(x+tex->getWidth()/2,y-tex->getHeight()/2)){
                    intersects = true;
                } else if ((*it)->contains(x+tex->getWidth()/2,y+tex->getHeight()/2)){
                    intersects = true;
                } else if ((*it)->contains(x-tex->getWidth()/2,y+tex->getHeight()/2)){
                    intersects = true;
                } else if ((*it)->contains(x,y)){
                    intersects = true;
                } else if ((*it)->contains(x-tex->getWidth()/2,y)){
                    intersects = true;
                } else if ((*it)->contains(x+tex->getWidth()/2,y)){
                    intersects = true;
                } else if ((*it)->contains(x,y-tex->getHeight()/2)){
                    intersects = true;
                } else if ((*it)->contains(x,y+tex->getHeight()/2)){
                    intersects = true;
                }
                if (intersects){
                    for(std::vector<int>::iterator itc = collideTypes.begin();itc != collideTypes.end();++itc){
                        if (*itc == (*it)->getType()){
                            bool nextMoving = false;
                            if (((*it)->getSpeed() >= speed) && ((*it)->getDirection() == dir)){
                                bool nextColliding = false;
                                if(std::distance(objects.find(type),objects.find((*it)->getType())) > 0){
                                    for(int i = 1; i <= (*it)->getSpeed(); i++){
                                        if (((*it)->place_meeting((*it)->getX()+i*cos(degToRad((*it)->getDirection())),(*it)->getY()+i*sin(degToRad((*it)->getDirection())),(*it)->getTexture(),*((*it)->getCollideTypes())))){
                                            nextColliding = true;
                                            break;
                                        }
                                    }
                                } else if (std::distance(objects.find(type),objects.find((*it)->getType())) == 0){
                                    if (std::distance(std::find((*i).second.begin(),(*i).second.end(),this),std::find((*i).second.begin(),(*i).second.end(),(*it))) > 0){
                                        for(int s = 1; s <= (*it)->getSpeed(); s++){
                                            if (((*it)->place_meeting((*it)->getX()+s*cos(degToRad((*it)->getDirection())),(*it)->getY()+s*sin(degToRad((*it)->getDirection())),(*it)->getTexture(),*((*it)->getCollideTypes())))){
                                                nextColliding = true;
                                                break;
                                            }
                                        }
                                    }
                                }
                                if (!(nextColliding)){
                                    nextMoving = true;
                                }
                            }
                            if (!(nextMoving) && ((*it)->attribute3 == 0)){
                                return true;
                            }
                        }
                    }
                }
            }
        }
    }
    return false;
}
bool Object::place_meeting(int x, int y, Object* obj){
    bool intersects = false;
    if (obj->contains(x,y)){
        intersects = true;
    } else if (obj->contains(x-tex->getWidth()/2,y)){
        intersects = true;
    } else if (obj->contains(x+tex->getWidth()/2,y)){
        intersects = true;
    } else if (obj->contains(x,y-tex->getHeight()/2)){
        intersects = true;
    } else if (obj->contains(x,y+tex->getHeight()/2)){
        intersects = true;
    }
    return intersects;
}
bool Object::place_meeting(Object* obj){
    bool intersects = false;
    if (obj->contains(x,y)){
        intersects = true;
    } else if (obj->contains(x-tex->getWidth()/2,y)){
        intersects = true;
    } else if (obj->contains(x+tex->getWidth()/2,y)){
        intersects = true;
    } else if (obj->contains(x,y-tex->getHeight()/2)){
        intersects = true;
    } else if (obj->contains(x,y+tex->getHeight()/2)){
        intersects = true;
    }
    return intersects;
}
bool Object::place_meeting(Object* obj, int width, int height){
    bool intersects = false;
    if (obj->contains(x,y)){
        intersects = true;
    } else if (obj->contains(x-width/2,y)){
        intersects = true;
    } else if (obj->contains(x+width/2,y)){
        intersects = true;
    } else if (obj->contains(x,y-height/2)){
        intersects = true;
    } else if (obj->contains(x,y+height/2)){
        intersects = true;
    }
    return intersects;
}
bool Object::place_meeting(Object* obj, float x, float y, float width, float height){
    bool intersects = false;
    if (obj->contains(x,y)){
        intersects = true;
    } else if (obj->contains(x-width/2,y)){
        intersects = true;
    } else if (obj->contains(x+width/2,y)){
        intersects = true;
    } else if (obj->contains(x,y-height/2)){
        intersects = true;
    } else if (obj->contains(x,y+height/2)){
        intersects = true;
    }
    return intersects;
}
bool Object::compByDepth(Object* i, Object* j){
    return ((i->getDepth())<(j->getDepth()));
}
bool Object::compByDrawDepth(Object* i, Object* j){
    return ((i->getDrawDepth())<(j->getDrawDepth()));
}
gTexture* Object::getTexture(){
    return tex;
}
void Object::draw(){
    if (attribute4 == 0){
        if (angle == 0){
            tex->render(x,y);
        } else {
            tex->renderEx(x,y,angle,NULL,SDL_FLIP_NONE);
        }
        if (attribute9 > 0){
            if (type == 1){
                SDL_SetRenderDrawColor(renderer,0,51,255,255);
            }
            if (type == 5){
                SDL_SetRenderDrawColor(renderer,128,128,128,255);
            }
            if (!attribute9array[0]){
                SDL_Rect drect = {x+(width/2)-attribute9,y-(height/2),attribute9,height};
                SDL_RenderFillRect(renderer,&drect);
            }
            if (!attribute9array[1]){
                SDL_Rect drect = {x-(width/2),y-(height/2),width,attribute9};
                SDL_RenderFillRect(renderer,&drect);
            }
            if (!attribute9array[2]){
                SDL_Rect drect = {x-(width/2),y-(height/2),attribute9,height};
                SDL_RenderFillRect(renderer,&drect);
            }
            if (!attribute9array[3]){
                SDL_Rect drect = {x-(width/2),y+(height/2)-attribute9,width,attribute9};
                SDL_RenderFillRect(renderer,&drect);
            }
            if (!attribute9array[4]){
                SDL_Rect drect = {x+(width/2)-attribute9,y-(height/2),attribute9,attribute9};
                SDL_RenderFillRect(renderer,&drect);
            }
            if (!attribute9array[5]){
                SDL_Rect drect = {x-(width/2),y-(height/2),attribute9,attribute9};
                SDL_RenderFillRect(renderer,&drect);
            }
            if (!attribute9array[6]){
                SDL_Rect drect = {x-(width/2),y+(height/2)-attribute9,attribute9,attribute9};
                SDL_RenderFillRect(renderer,&drect);
            }
            if (!attribute9array[7]){
                SDL_Rect drect = {x+(width/2)-attribute9,y+(height/2)-attribute9,attribute9,attribute9};
                SDL_RenderFillRect(renderer,&drect);
            }
        }
    } else if (type == 5){
            SDL_SetRenderDrawColor(renderer,128,128,128,255);

            if (!attribute9array[0]){
                SDL_Rect drect = {x+(width/2)-attribute9,y-(height/2),attribute9,height};
                SDL_RenderFillRect(renderer,&drect);
            }
            if (!attribute9array[1]){
                SDL_Rect drect = {x-(width/2),y-(height/2),width,attribute9};
                SDL_RenderFillRect(renderer,&drect);
            }
            if (!attribute9array[2]){
                SDL_Rect drect = {x-(width/2),y-(height/2),attribute9,height};
                SDL_RenderFillRect(renderer,&drect);
            }
            if (!attribute9array[3]){
                SDL_Rect drect = {x-(width/2),y+(height/2)-attribute9,width,attribute9};
                SDL_RenderFillRect(renderer,&drect);
            }
            if (!attribute9array[4]){
                SDL_Rect drect = {x+(width/2)-attribute9,y-(height/2),attribute9,attribute9};
                SDL_RenderFillRect(renderer,&drect);
            }
            if (!attribute9array[5]){
                SDL_Rect drect = {x-(width/2),y-(height/2),attribute9,attribute9};
                SDL_RenderFillRect(renderer,&drect);
            }
            if (!attribute9array[6]){
                SDL_Rect drect = {x-(width/2),y+(height/2)-attribute9,attribute9,attribute9};
                SDL_RenderFillRect(renderer,&drect);
            }
            if (!attribute9array[7]){
                SDL_Rect drect = {x+(width/2)-attribute9,y+(height/2)-attribute9,attribute9,attribute9};
                SDL_RenderFillRect(renderer,&drect);
            }
    }
}
