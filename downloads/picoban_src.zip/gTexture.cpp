#include "gTexture.h"

gTexture::gTexture()
{
    sdlTex = NULL;
    width = 0;
    height = 0;
}

gTexture::~gTexture()
{
    free();
}

void gTexture::free(){
    SDL_DestroyTexture(sdlTex);
    sdlTex = NULL;
}

bool gTexture::loadFile(std::string path, bool colorKey, Uint8 r, Uint8 g, Uint8 b){
    SDL_Surface* surfLoad = IMG_Load(path.c_str());
    if (surfLoad == NULL){
        printf("texture loading error at");
        printf(path.c_str());
        return 0;
    } else {
        if (colorKey){
            SDL_SetColorKey(surfLoad,SDL_TRUE,SDL_MapRGB(surfLoad->format,r,g,b));
        }
        sdlTex = SDL_CreateTextureFromSurface(renderer,surfLoad);
        if(sdlTex == NULL){
            printf("texture loading error with");
            printf(path.c_str());
            return 0;
        } else {
            width = surfLoad->w;
            height = surfLoad->h;
        }
        SDL_FreeSurface(surfLoad);
    }
    return 1;
}

bool gTexture::loadFRText(std::string str, TTF_Font* font, SDL_Color col){
    free();

    SDL_Surface* surfText = TTF_RenderText_Solid(font,str.c_str(),col);
    if (surfText == NULL){
        printf("could not render text surface");
        return 0;
    } else {
        sdlTex = SDL_CreateTextureFromSurface(renderer,surfText);
        if (sdlTex == NULL){
            printf("could not create texture from text surface");
            return 0;
        }
        else {
            width = surfText ->w;
            height = surfText ->h;
        }

        SDL_FreeSurface(surfText);
    }
    return 1;
}

void gTexture::render(int x, int y){
    SDL_Rect renderRect = {x-(width/2),y-(height/2), width,height};
    SDL_RenderCopy(renderer, sdlTex, NULL, &renderRect);
}

void gTexture::renderCenter(int x, int y, int centerType){
    if (centerType == 0){
        SDL_Rect renderRect = {x,y, width,height};
        SDL_RenderCopy(renderer, sdlTex, NULL, &renderRect);
    }
    else if (centerType == 1){
        SDL_Rect renderRect = {x-width,y, width,height};
        SDL_RenderCopy(renderer, sdlTex, NULL, &renderRect);
    }
    else if (centerType == 2){
        SDL_Rect renderRect = {x-(width/2),y, width,height};
        SDL_RenderCopy(renderer, sdlTex, NULL, &renderRect);
    }
}
void gTexture::renderEx(int x, int y, double angle, SDL_Point* center, SDL_RendererFlip flip){
    SDL_Rect renderRect = {x-(width/2),y-(height/2), width,height};
    SDL_RenderCopyEx(renderer, sdlTex, NULL, &renderRect, angle, center, flip);
}


Uint8 gTexture::getWidth(){
    return width;
}

Uint8 gTexture::getHeight(){
    return width;
}
